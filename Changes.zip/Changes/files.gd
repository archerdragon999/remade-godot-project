extends Node

func get_file(file: String, subfiles: String = "") -> String:
	var path = "res://" + subfiles + file if subfiles == "" else "res://" + subfiles + "/" + file
	if FileAccess.file_exists(path):
		return path
	else:
		push_error("File: '", path + "' not found.")
		return ""

func give_birth(parent: Node, file: String, subfiles: String = "") -> Node:
	var path := get_file(file, subfiles)
	if path == "":
		return null
	var scene := load(path)
	var instance = scene.instantiate()
	parent.add_child(instance)
	return instance
