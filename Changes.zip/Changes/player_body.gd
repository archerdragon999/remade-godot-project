extends CharacterBody2D

var jump_counter: int = 0

func slap_n_give_birth(scene_path: String):
	var directed_scene = load(scene_path)
	var nodeee = directed_scene.instantiate()
	add_child(nodeee)


func is_falling():
	return velocity.y > 0

func can_jump():
	if is_on_floor() and jump_counter > 0:
		return true
	elif jump_counter > 0:
		jump_counter -= 1
		return true
	else:
		return false

func _ready() -> void:
	slap_n_give_birth("res://Scenes/camera.tscn")
	pass




func _physics_process(delta: float) -> void:
	PlayerData.player_velocity = velocity
	# Add gravity.
	if is_on_floor():
		jump_counter = PlayerData.jump_amount
		velocity.y = 0
	elif is_falling():
		velocity.y += GameData.gravity * 2.5 * delta
		
	else:
		velocity.y += GameData.gravity * delta
	
	# Handle jump.
	if Input.is_action_just_pressed("action_jump"):
		if can_jump():
			velocity.y = -(PlayerData.jump_power)
			jump_counter -= 1
	
	
	
	# Movement
	var direction := Input.get_axis("action_left", "action_right")
	if direction:
		velocity.x = direction * PlayerData.walk_speed
	elif is_on_floor():
		velocity.x *= GameData.friction
	elif not PlayerData.maintain_horizontal_fall_vel:
		velocity.x *= PlayerData.horizontal_fall_friction
	
	move_and_slide()
