extends Node

var jump_power: int = 530
var jump_amount: int = 2
var walk_speed: int = 500
var run_speed: int = 800
var maintain_horizontal_fall_vel: bool = false
var horizontal_fall_friction: float = 0.9
var player_velocity: Vector2
func _ready() -> void:
	pass
