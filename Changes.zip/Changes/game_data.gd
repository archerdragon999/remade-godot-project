extends Node

var gravity: int = 1000
var friction: float = 0.8
var game_level: String = "1"
var time_amount: int = 120
func _ready() -> void:
	pass # Replace with function body.
