extends Control


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass


func _on_singleplayer_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/base_scene.tscn")


func _on_multiplayer_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/multiplayer_base_scene.tscn")


func _on_quit_pressed() -> void:
	get_tree().quit()
